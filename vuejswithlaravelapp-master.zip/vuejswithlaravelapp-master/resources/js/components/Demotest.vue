<script setup>
defineProps({
  msg: String,
});
</script>
<template>
  <h2>Demotest {{ msg }}</h2>
</template>